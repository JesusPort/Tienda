package vista;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelo.dao.ComponenteDao;
import modelo.dao.TipoDao;
import modelo.dao.VentaDao;
import modelo.data.Componente;
import modelo.data.Tipo;
import modelo.data.Venta;

public class Menu {
	   private Scanner scanner;
	   private static int idcomponente;
	   public Menu() {
	       scanner = new Scanner(System.in);
	   }

	   public void displayMenu() {
	       int option;
	       do {
	           System.out.println("1. CREAR UN TIPO ");
	           System.out.println("2. MOSTRAR POR PANTALLA TODOS LOS TIPOS");
	           System.out.println("3. BORRAR UN TIPO");
	           System.out.println ("4. Actualizar tipo");
	           System.out.println("5. CREAR COMPONENTE");
	           System.out.println("6. MOSTRAR TODOS LOS COMPONENTES");
	           System.out.println(" MOSTRAR UN COMPONENTE EN ESPECIFICO");
	           System.out.println(" 8. ACTUALIZAR UN COMPONENTE");
	           System.out.println(" 9. BORRAR COMPONENTE");
	           System.out.println("10.CREAR VENTA");
	           System.out.println("11.ACTUALIZAR VENTA");
	           System.out.println("12. Mostrar lista venta");
	           option = scanner.nextInt();

	           switch (option) {
	               case 1:
	            	   crearTipo();
	                  break;
	               case 2:
	            	   mostrarTipos() ;
	                  break;
	               case 3:
	            	   borrarTipo();
	                  break;
	               case 4:
	            	   Actualizartipo();
	            	   break;
	               case 5:
	            	   crearComponente();
	            	   break;
	               case 6:
	            	  listarComponentes();
	            	   break;
	               case 7:
	            	   mostrar1Componentes();
	            	   break;
	               case 8:
	            	   actualizarComponentes();
	               break;
	               case 9:
	            	   borrarCom();
	            	   break;
	               case 10:
	            	   insertarUnaVenta();
	            	   break;
	               case 11:
	            	   IntroducirDatosVenta();
	            	   break;
	               case 12:
	            	   System.out.println("Saliendo...");
	            	   break;
	               default:
	                  System.out.println("Opcion Incorrecta.");
	           }
	       } while (option != 10);
	   }

	   private void IntroducirDatosVenta() {
		   Scanner scanner = new Scanner(System.in);
		    
		    System.out.println("Ingrese el importe de la venta:");
		    int importeVenta = scanner.nextInt();
		    scanner.nextLine(); 
		    
		    System.out.println("Ingrese la descripción de la venta:");
		    String descripcion = scanner.nextLine();
		    
		   Venta v = new Venta(0,importeVenta,descripcion);
		   VentaDao.insertarDatosVenta(v);
		
	}

	private void insertarUnaVenta() {
		 Scanner scanner = new Scanner(System.in);

		    System.out.println("Ingrese el importe de la venta:");
		    double importeVenta = scanner.nextDouble();
		    scanner.nextLine();

		    System.out.println("Ingrese la descripción de la venta:");
		    String descripcion = scanner.nextLine();

		    // Crear una venta con los datos ingresados
		    Venta venta = new Venta(0, importeVenta, descripcion);

		    System.out.println("Ingrese la cantidad de componentes:");
		    int cantidadComponentes = scanner.nextInt();
		    scanner.nextLine();

		    // Crear una lista para almacenar los componentes de la venta
		    List<Componente> listaComponentes = new ArrayList<>();

		    for (int i = 0; i < cantidadComponentes; i++) {
		        System.out.println("Ingrese el nombre del componente " + (i + 1) + ":");
		        String nombreComponente = scanner.nextLine();

		        System.out.println("Ingrese el fabricante del componente " + (i + 1) + ":");
		        String fabricante = scanner.nextLine();
		        
		        System.out.println("Ingrese el importe del componente " + (i + 1) + ":");
		        double precio = scanner.nextDouble();
		        
		        scanner.nextLine();
		        
		        System.out.println("Ingrese la descripcion del componente " + (i + 1) + ":");
		        String descripcionComponente = scanner.nextLine();
		        
		        System.out.println("Ingrese el tipo del componente " + (i + 1) + ":");
		        String nombreTipoComponente = scanner.nextLine();
		        
		        Tipo tipoComponente = new Tipo(0, nombreTipoComponente);
		     
		        
		       

		        Componente componente = new Componente(0,nombreComponente, fabricante, precio, descripcionComponente, tipoComponente);
		        listaComponentes.add(componente);
		    }

		    // Asignar la lista de componentes a la venta
		    venta.setListaComponentes(listaComponentes);

		    // Llamar al método de VentaDao para insertar la nueva venta
		    VentaDao.insertarNuevaVenta(venta);
		}

		
	private void crearComponente() {
		   Scanner scanner = new Scanner(System.in);

		   System.out.println("Introduce el ID del componente:");
		   int id = scanner.nextInt();

		   System.out.println("Introduce el nombre del componente:");
		   scanner.nextLine(); 
		   String nombre = scanner.nextLine();

		   System.out.println("Introduce el fabricante del componente:");
		   String fabricante = scanner.nextLine();

		   System.out.println("Introduce el precio del componente:");
		   double precio = scanner.nextDouble();

		   System.out.println("Introduce la descripción del componente:");
		   scanner.nextLine(); 
		   String descripcion = scanner.nextLine();

		   System.out.println("Introduce el id del tipo del componente:");
		   int idTipo = scanner.nextInt();
		   
		   System.out.println("Introduce el tipo del componente:");
		   String tipo = scanner.nextLine();

		   
		   Componente c = new Componente(id, nombre, fabricante, precio, descripcion, new Tipo(idTipo, tipo));
		   ComponenteDao.insertarUnComponente(c);
		
	   	}
 
	private void listarComponentes() {
		ComponenteDao.seleccionarComponente().forEach(System.out::println);
	   }
	private void mostrar1Componentes() {
		
		 Scanner scanner = new Scanner(System.in);
		System.out.println("INTROUDUCE EL ID DEL PRODUCUTO QUE QUIERES VISUALIZAR");
		int id=scanner.nextInt();
		
		ComponenteDao.seleccionarUncomponente(id).forEach(System.out::println);;
		
	}
	private void actualizarComponentes() {
		int opcion;
		int id;
		System.out.println(" De los siguentes componentes , SELECCIONA EL ID DEL COMPONENTE QUE QUIERES MODIFICAR");
		System.out.println("---------LISTA COMPONENETES---------");
		listarComponentes();
		System.out.println("---------LISTA COMPONENETES---------");
		
		idcomponente=scanner.nextInt();
		
		do {
			System.out.println("1, ACTUALIZAR NOMBRE DEL COMPONENTE");
			System.out.println(" 2. ACTUALIZAR EL FABRICANTE DEL COMPONENTE");
			System.out.println(" 3. ACTUALIZAR EL PRECIO DEL FABRICANTE");
			System.out.println(" 4. ACTUALIZAR LA DESCRIPCION DEL COMPONENTE");
			System.out.println("5. FINALIZAR LA ACTUALIZACION");
			
			opcion = scanner.nextInt();
			switch(opcion) {
			case 2:
				UpdateFabricante();
				
				break;
			case 1:
				UpdateCom_Nombre();
				break;
			case 3:
				UpdateCom_p();
				break;
			case 4:
				UpdateCom_Desc();
				break;
				
			case 5:
				System.out.println(" ACTUALIZACION FINALIZADA ");
				displayMenu();
			}
			
		}while(opcion!=7);
		
		
	}
	private void UpdateCom_p() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				Scanner scanner = new Scanner(System.in);
				System.out.println(" introudce el nuevo precio");
				double f=scanner.nextDouble();
				ComponenteDao.updateComponentePrecio(idcomponente, f);
				System.out.println(" precio ACTUALIZADA");
	}

	private void UpdateCom_Desc() {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println(" introudce la nueva descripcion");
		String f=scanner.nextLine();
		ComponenteDao.updateComponentedescripcion(idcomponente, f);
		System.out.println(" DESCRIPCION ACTUALIZADA");
	}

	private void UpdateCom_Nombre() {
		// TODO Auto-generated method stub
		   Scanner scanner = new Scanner(System.in);
			System.out.println(" introudce el nuevo nombre del componente");
			String f=scanner.nextLine();
			ComponenteDao.updateComponentenombre(idcomponente, f);
			System.out.println(" NOMBRE ACTUALIZADO");
	}

	private void UpdateFabricante() {
		// TODO Auto-generated method stub
		   Scanner scanner = new Scanner(System.in);
		System.out.println(" introudce el nombre del nuevo fabricante");
		String f=scanner.nextLine();
		ComponenteDao.updateComponenteFabricante(idcomponente, f);
		System.out.println(" FABRICANTE ACTUALIZADO");
	}

	public 	void borrarCom() {
		
		
		   Scanner scanner = new Scanner(System.in);
		   System.out.println("introduce el nombre del componente");
		   String Ncomponente=scanner.nextLine();
		   
		   ComponenteDao.borrarComponente(Ncomponente);
	}
	private void Actualizartipo() {
		

		   Scanner scanner = new Scanner(System.in);
		   
		   System.out.println("INTRODUCE EL ID DEL TIPO");
		   int id=scanner.nextInt();
		   
		   scanner.nextLine();
		   
		   System.out.println("introduce el nombre del tipo");
		   String Ncomponente=scanner.nextLine();
		
		   TipoDao.UpdateTipo(id, Ncomponente);
	}
	private void crearTipo() {
		Scanner t=new Scanner(System.in); 
		System.out.println("INTRODUCE EL NOMBRE DEL TIPO");
		System.out.println("LOS NOMBRES DE LOS TIPOS SOLO PUEDEN LOS SIGUENTES (CPU,GPU,RAM,PLACA_BASE,ALMACENAMIENTO)");
		
		String n=t.nextLine();
		
		Tipo tipo=new Tipo(0,n);
		TipoDao.insertarUnTipo(tipo);
	}
	private void mostrarTipos() {

		
		System.out.println("=============LISTA DE TIPOS ================");
		TipoDao.seleccionarTipos().forEach(System.out::println);
		System.out.println("=============LISTA DE TIPOS ================");
	}
	private void borrarTipo() {
		
			System.out.println("De los siguentes tipos ");
			System.out.println("=============LISTA DE TIPOS ================");
			mostrarTipos();
			System.out.println("=============LISTA DE TIPOS ================");
			 TipoDao.seleccionarTipos().forEach(System.out::println);
			    System.out.println("Ingrese el ID del tipo que desea borrar:");
			    int idTipo = scanner.nextInt();
			    boolean borrado = TipoDao.deleteTipo(idTipo);
			    if (borrado) {
			        System.out.println("Tipo eliminado correctamente.");
			    } else {
			        System.out.println("No se pudo eliminar el tipo.");
			    }
		
	}
}


