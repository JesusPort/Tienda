/**
 * 
 */
/**
 * @author Usuario
 *
 */
module tienda_hardware {
	requires java.sql;
}