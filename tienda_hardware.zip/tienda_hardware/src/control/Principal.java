package control;

import modelo.dao.ComponenteDao;
import modelo.dao.TipoDao;
import modelo.data.Componente;
import modelo.data.Tipo;
import vista.Menu;

public class Principal {

	 public static void main(String[] args) {
	       Menu menu = new Menu();
	       menu.displayMenu();
	   }

}
