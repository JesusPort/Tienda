package modelo.data;

import java.util.List;

public class Venta {

	private int idVenta;
	private double importeV;
	private String descripcion;
	private List<Componente> listaComponentes;
	public Venta() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Venta(int idVenta, double importeV, String descripcion) {
		super();
		this.idVenta = idVenta;
		this.importeV = importeV;
		this.descripcion = descripcion;
	}
	@Override
	public String toString() {
		return "Venta [idVenta=" + idVenta + ", importeV=" + importeV + ", descripcion=" + descripcion + "]";
	}
	public int getIdVenta() {
		return idVenta;
	}
	public void setIdVenta(int idVenta) {
		this.idVenta = idVenta;
	}
	public double getImporteV() {
		return importeV;
	}
	public void setImporteV(double importeV) {
		this.importeV = importeV;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public List<Componente> getListaComponentes() {
		return listaComponentes;
	}
	public void setListaComponentes(List<Componente> listaComponentes) {
		this.listaComponentes = listaComponentes;
	}
	public void addComponentesList(Componente c) {
		this.listaComponentes.add(c);
	}
	
	
}
