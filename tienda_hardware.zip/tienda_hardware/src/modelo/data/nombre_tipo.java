package modelo.data;

public enum nombre_tipo {

	CPU,
	GPU,
	RAM,
	PLACA_BASE,
	ALMACENAMIENTO;
	
}