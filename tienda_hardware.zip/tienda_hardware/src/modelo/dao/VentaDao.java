package modelo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import modelo.data.Componente;
import modelo.data.Venta;

public class VentaDao {
	private static Connection connection;
	
	
	public static void insertarNuevaVenta(Venta v) {
		int idComponente=0;
		
		insertarDatosVenta(v);
		
		int idVenta= isVentaInBD(v.getDescripcion());
		
		for  (Componente c: v.getListaComponentes()){
			if((idComponente=ComponenteDao.isComInBD(c.getFabricante()))==0) {
				ComponenteDao.insertarUnComponente(c);
				idComponente=ComponenteDao.isComInBD(c.getFabricante());
			}
			insertarVentaComponente(idVenta,idComponente);
		}
	}
	
	public static void insertarVentaComponente(int idVenta, int idComponente) {
		Conexion con =new Conexion();
		connection= con.getJdbcConnection();		
		// Ejecutamos la sentencia
		try {
			Statement statement = connection.createStatement();
	
			String sql = "insert into venta_componente (venta_id,componente_id) values (" + idVenta + "," + idComponente + ")";
			boolean rowInserted = statement.executeUpdate(sql) > 0;
		} catch (SQLException e1) {			
			e1.printStackTrace();
		}		
		
	}
	
	public static void insertarDatosVenta(Venta v) {
		Conexion con =new Conexion();
		connection= con.getJdbcConnection();		
		// Ejecutamos la sentencia
		try {
			Statement statement = connection.createStatement();
	
			String sql = "insert into venta(importeTotal,descripcionV) values ('"+v.getImporteV()+"','"+v.getDescripcion()+"')";
			boolean rowInserted = statement.executeUpdate(sql) > 0;
		} catch (SQLException e1) {			
			e1.printStackTrace();
		}		
		
	}
public static int isVentaInBD(String Desc) {
		
		ResultSet rs;
		int idVenta=0;
		Conexion con =new Conexion();
		connection= con.getJdbcConnection();	
		try {
			Statement statement = connection.createStatement();
		    String sql= "select ID_venta from venta where descripcionV='"+Desc+"'";
			rs=statement.executeQuery(sql);
			if(rs.next()) {				
				idVenta=rs.getInt(1);
			}
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}		
		
		return idVenta;

	}
}
