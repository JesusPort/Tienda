package modelo.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import modelo.data.Componente;
import modelo.data.Tipo;

public class ComponenteDao {
	private static Connection connection;
	
	public static boolean insertarUnComponente(Componente componente) {
		Conexion con= new Conexion();
		connection=con.getJdbcConnection();
		boolean rowInserted=false;
		try {
			Statement sentencia= connection.createStatement();
			
			//Si el tipo no esta en los tipos de la base de datos
			int idTipo=0;
			if((idTipo= TipoDao.isTipoInBD(componente.getTipo().getNombre()))==0) {
				TipoDao.insertarUnTipo(componente.getTipo());
				idTipo=TipoDao.isTipoInBD(componente.getTipo().getNombre());
			}
			String sql="INSERT INTO componente values("+componente.getID_componente()+",'"+componente.getNombre_componente()+"',"+
			"'"+componente.getFabricante()+"',"+componente.getPrecio()+","+"'"+componente.getDescripcion()+"',"+idTipo+")";
			
					
			rowInserted=sentencia.executeUpdate(sql)>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rowInserted;
	}
	
	
	public static List<Componente> seleccionarComponente(){
		List<Componente> listaComponente= new ArrayList<Componente>();
		ResultSet rs;
		Conexion con= new Conexion();
		connection=con.getJdbcConnection();
		
		try {
			Statement sentencia= connection.createStatement();
			String sql="SELECT c.*,t.* FROM componente c, tipo t WHERE c.ID_tipo=t.id_tipo";
			rs=sentencia.executeQuery(sql);
			
			while(rs.next()) {
				listaComponente.add(new Componente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getString(5),new Tipo(rs.getInt(6),rs.getString(7))));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaComponente;
	}
	
	public static List<Componente>seleccionarUncomponente(int id){
		List<Componente> listaComponente= new ArrayList<Componente>();
		
		ResultSet rs;
		Conexion con= new Conexion();
		connection=con.getJdbcConnection();
		
		try {
			Statement sentencia= connection.createStatement();
			String sql="SELECT c.*,t.* FROM componente c, tipo t WHERE c.ID_tipo="+id;
			rs=sentencia.executeQuery(sql);
			
			while(rs.next()) {
				listaComponente.add(new Componente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getString(5),new Tipo(rs.getInt(6),rs.getString(7))));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaComponente;
		
		
		
	}
	public static boolean borrarComponente(String nombreComponente) {

		Conexion con=new Conexion();
		connection=con.getJdbcConnection();
		boolean rowDeleted=false;
		try {
			Statement st=connection.createStatement();
			String sql="Delete from componente where nombre_componente= '" + nombreComponente + "'";
			rowDeleted=st.executeUpdate(sql)>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rowDeleted;
	}
	
	
	
	
	public static boolean UpdateComponente(String nombreComponente, Componente nuevoComponente) {
		
		boolean rowUpdate=false;
		Conexion con=new Conexion();
		connection=con.getJdbcConnection();
		int idTipo=0;
		try {
			Statement st=connection.createStatement();
			
			if((idTipo= TipoDao.isTipoInBD(nuevoComponente.getTipo().getNombre()))==0) {
			
				 String sql = "UPDATE componente SET ID_componente=" + nuevoComponente.getID_componente() +
		                    ", nombre_componente='" + nuevoComponente.getNombre_componente() +
		                    "', Fabricante='" + nuevoComponente.getFabricante() +
		                    "', precio=" + nuevoComponente.getPrecio() +
		                    ", Descripcion='" + nuevoComponente.getDescripcion() +
		                    "', id_tipo=" + idTipo +
		                    " WHERE nombre_componente='" + nombreComponente + "'";
				
				rowUpdate=st.executeUpdate(sql)>0;
			}else {
				System.out.println(" No se puede llevar a cabo el update porque +" +nuevoComponente.getTipo().getId_tipo()+ "no existe en la base de datos");
			}
			
			
	
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		return rowUpdate;
	}
	
	
	public static boolean updateComponenteFabricante(int idComponente, String newFabricante) {
	    boolean rowUpdate = false;
	    Conexion con = new Conexion();
	    connection = con.getJdbcConnection();

	    try {
	        Statement st = connection.createStatement();
	        String sql = "UPDATE componente SET Fabricante='" + newFabricante + "' WHERE ID_componente=" + idComponente;
	        rowUpdate = st.executeUpdate(sql) > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return rowUpdate;
	}

	public static boolean updateComponentenombre(int idComponente, String newNom) {
	    boolean rowUpdate = false;
	    Conexion con = new Conexion();
	    connection = con.getJdbcConnection();

	    try {
	        Statement st = connection.createStatement();
	        String sql = "UPDATE componente SET nombre_componente='" + newNom + "' WHERE ID_componente=" + idComponente;
	        rowUpdate = st.executeUpdate(sql) > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return rowUpdate;
	}
	
	public static boolean updateComponentedescripcion(int idComponente, String newDesc) {
	    boolean rowUpdate = false;
	    Conexion con = new Conexion();
	    connection = con.getJdbcConnection();

	    try {
	        Statement st = connection.createStatement();
	        String sql = "UPDATE componente SET Descripcion='" + newDesc + "' WHERE ID_componente=" + idComponente;
	        rowUpdate = st.executeUpdate(sql) > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return rowUpdate;
	}
	
	
	public static boolean updateComponentePrecio(int idComponente, double precio) {
	    boolean rowUpdate = false;
	    Conexion con = new Conexion();
	    connection = con.getJdbcConnection();

	    try {
	        Statement st = connection.createStatement();
	        String sql = "UPDATE componente SET precio=" + precio + " WHERE ID_componente=" + idComponente;
	        rowUpdate = st.executeUpdate(sql) > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return rowUpdate;
	}
	
	
	public static int isComInBD(String fabricante) {
		
		ResultSet rs;
		int idComponente=0;
		Conexion con =new Conexion();
		connection= con.getJdbcConnection();	
		try {
			Statement statement = connection.createStatement();
		    String sql= "select iD_componente from componente where Fabricante='"+fabricante+"'";
			rs=statement.executeQuery(sql);
			if(rs.next()) {
				
				idComponente=rs.getInt(1);
			}
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}		
		
		return idComponente;
		
	}
	
}
